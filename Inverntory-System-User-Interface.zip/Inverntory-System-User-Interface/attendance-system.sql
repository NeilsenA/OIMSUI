<!DOCTYPE html>
<html>
   <head>
      <title>Library System</title>
      <meta http-equiv = "refresh" content = "0; url = pages/login/login.php" />
   </head>
   <body>
       <p>redirecting...</p>
   </body>
</html>