      <!-- partial:../../partials/_sidebar.html -->
      <nav class="sidebar sidebar-offcanvas" id="sidebar" style="background-color:#bddcff;">
          <ul class="nav">
              <li class="nav-item">
                  <a class="nav-link" href="../dashboard/dashboard.php">
                      <i class="ti-shield menu-icon"></i>
                      <span class="menu-title">Dashboard</span>
                  </a>
              </li>
              <li class="nav-item">
                  <a class="nav-link" href="../company/company.php">
                      <i class="ti-flag menu-icon"></i>
                      <span class="menu-title">Company Setup</span>
                  </a>
              </li>
              <li class="nav-item">
                  <a class="nav-link" href="../product/product.php">
                      <i class="ti-shopping-cart menu-icon"></i>
                      <span class="menu-title">Products</span>
                  </a>
              </li>
              <li class="nav-item">
                  <a class="nav-link" href="../productset/productset.php">
                      <i class="ti-shopping-cart menu-icon"></i>
                      <span class="menu-title">Product Sets</span>
                  </a>
              </li>
              <li class="nav-item">
                  <a class="nav-link" href="../unit/unit.php">
                      <i class="ti-layers menu-icon"></i>
                      <span class="menu-title">Units</span>
                  </a>
              </li>
              <li class="nav-item">
                  <a class="nav-link" href="../category/category.php">
                      <i class="ti-layers-alt menu-icon"></i>
                      <span class="menu-title">Categories</span>
                  </a>
              </li>
              <li class="nav-item">
                  <a class="nav-link" href="../ItemRawMaterial/ItemRawMaterial.php">
                      <i class="ti-file menu-icon"></i>
                      <span class="menu-title">Item Raw Material</span>
                  </a>
              </li>
              <li class="nav-item">
                  <a class="nav-link" href="../invoice/invoice.php">
                      <i class="ti-shopping-cart-full menu-icon"></i>
                      <span class="menu-title">Invoice</span>
                  </a>
              </li>
              <li class="nav-item">
                  <a class="nav-link" href="../sales/sales.php">
                      <i class="ti-bar-chart-alt menu-icon"></i>
                      <span class="menu-title">Sales</span>
                  </a>
              </li>
              <li class="nav-item">
                  <a class="nav-link" href="../users/users.php">
                      <i class="ti-user menu-icon"></i>
                      <span class="menu-title">Users</span>
                  </a>
              </li>
              <li class="nav-item">
                  <a class="nav-link" href="../userlog/userlog.php">
                      <i class="ti-user menu-icon"></i>
                      <span class="menu-title">User Log</span>
                  </a>
              </li>
              <li class="nav-item">
                  <a class="nav-link" href="../auditlog/auditlog.php">
                      <i class="ti-time menu-icon"></i>
                      <span class="menu-title">Audit Log</span>
                  </a>
              </li>
          </ul>
      </nav>
      <!-- partial -->